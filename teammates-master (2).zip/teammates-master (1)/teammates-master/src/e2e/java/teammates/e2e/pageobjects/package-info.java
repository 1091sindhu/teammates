/**
 * Contains abstractions of the pages as they appear on a Web browser (i.e. SUTs).
 */
package teammates.e2e.pageobjects;
