/**
 * Contains all API request formats.
 */
package teammates.ui.request;
