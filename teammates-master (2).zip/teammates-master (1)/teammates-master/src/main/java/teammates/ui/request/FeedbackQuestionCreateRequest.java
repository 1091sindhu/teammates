package teammates.ui.request;

/**
 * The create request of a feedback question.
 */
public class FeedbackQuestionCreateRequest extends FeedbackQuestionBasicRequest {
}
