/**
 * Contains specific logs-related classes.
 */
package teammates.common.datatransfer.logs;
