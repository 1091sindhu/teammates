/**
 * Contains lightweight data transfer objects for transferring data
 * between components, particularly those from different packages.
 */
package teammates.common.datatransfer;
