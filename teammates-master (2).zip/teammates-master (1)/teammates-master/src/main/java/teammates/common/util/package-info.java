/**
 * Contains utility classes and helpers to be used by all components of the application.
 */
package teammates.common.util;
