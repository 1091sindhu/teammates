/**
 * Contains classes for dealing with searching and indexing.
 */
package teammates.storage.search;
