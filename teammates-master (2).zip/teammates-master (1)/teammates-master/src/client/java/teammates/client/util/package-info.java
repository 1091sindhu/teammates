/**
 * Contains utility classes for scripts dealing with the back end data.
 */
package teammates.client.util;
