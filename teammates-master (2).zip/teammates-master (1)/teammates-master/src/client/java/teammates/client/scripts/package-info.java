/**
 * Contains scripts that deal with the back end data for administrative purposes.
 */
package teammates.client.scripts;
