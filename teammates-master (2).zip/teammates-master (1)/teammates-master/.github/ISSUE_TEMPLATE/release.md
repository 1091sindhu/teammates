---
name: Release
about: (for core team) Schedule and manage a release

---

<!-- Issue title: Release VX.Y.Z -->

Scheduled for <!-- insert date and time here, e.g. Thursday, Sep 20, 2018, 10.00am SGT -->.

Release Lead:

- [ ] Tagged the latest stable release code with the latest version number
- [ ] Released changelogs

PM:

- [ ] Deployed the new version
- [ ] Released the new version for end users
